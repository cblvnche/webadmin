<center>
<h3>Server uptime:</h4>
<h5><?php
echo exec('uptime');
?></h5>
<br><br>
<h4>Logged in users:</h4>
<?php
echo exec('who');
?>

<meta http-equiv="refresh" content="10">

<br>
<br>
<style>
/* Стили кнопки */
.iksweb{display: inline-block;cursor: pointer; font-size:14px;text-decoration:none;padding:10px 20px; color:#354251;background:#ffff0;border-radius:0px;border:2px solid #354251;}
.iksweb:hover{background:#354251;color:#ffffff;border:2px solid #354251;transition: all 0.6s ease;}
</style>

<a class="iksweb" href="/"  rel="nofollow" title="Back to main">Back to main</a>
