<center>
<h5>Current time on server:
<?php
echo exec('date');
?>
</h5>

<center>
<p><span style="color:#2980b9"><span style="font-family:Verdana,Geneva,sans-serif"><strong>Linux Server</strong></span> | <span style="font-size:24px"><strong>Mini WEB-controller</strong></span></span></p>

<style>
/* Стили кнопки */
.iksweb{display: inline-block;cursor: pointer; font-size:14px;text-decoration:none;padding:10px 20px; color:#354251;background:#ffff0;border-radius:0px;border:2px solid #354251;}
.iksweb:hover{background:#354251;color:#ffffff;border:2px solid #354251;transition: all 0.6s ease;}
</style>

<a class="iksweb" href="terminal.php"  rel="nofollow" title="Web terminal">Web terminal</a>

<style>
/*    ^                     */
.iksweb{display: inline-block;cursor: pointer; font-size:14px;text-decoration:none;padding:10px 20px; color:#354251;background:#ffff0;border-radius:0px;border:2px solid #354251;}
.iksweb:hover{background:#354251;color:#ffffff;border:2px solid #354251;transition: all 0.6s ease;}
</style>

<a class="iksweb" onClick="self.location='uptime.php'"  rel="nofollow" title="Uptime">Uptime</a>


<style>
.iksweb{display: inline-block;cursor: pointer; font-size:14px;text-decoration:none;padding:10px 20px; color:#354251;background:#ffff0;border-radius:0px;border:2px solid #354251;}
.iksweb:hover{background:#354251;color:#ffffff;border:2px solid #354251;transition: all 0.6s ease;}
</style>

<a class="iksweb" href="reboot.php"  rel="nofollow" title="Reboot">Reboot</a>

<style>
/* Стили кнопки */
.iksweb{display: inline-block;cursor: pointer; font-size:14px;text-decoration:none;padding:10px 20px; color:#354251;background:#ffff0;border-radius:0px;border:2px solid #354251;}
.iksweb:hover{background:#354251;color:#ffffff;border:2px solid #354251;transition: all 0.6s ease;}
</style>

<a class="iksweb" href="poweroff.php"  rel="nofollow" title="Power off">Power off</a>

<br><br>
<style>
/* Стили кнопки */
.iksweb{display: inline-block;cursor: pointer; font-size:14px;text-decoration:none;padding:10px 20px; color:#ffffff;background:#383838;border-radius:0px;border:2px solid #354251;}
.iksweb:hover{background:#ffffff;color:#262626;border:2px solid #354251;transition: all 0.6s ease;}
</style>

<a class="iksweb" href="/"   title="Exit app">Exit app</a>
