<style>
/* Стили кнопки */
.iksweb{display: inline-block;cursor: pointer; font-size:14px;text-decoration:none;padding:10px 20px; color:#354251;background:#ffff0;border-radius:0px;border:2px solid #354251;}
.iksweb:hover{background:#354251;color:#ffffff;border:2px solid #354251;transition: all 0.6s ease;}
</style>

<a class="iksweb" href="/"  rel="nofollow" title="Back to main">Back to main</a>







<?php
 exec('/var/www/html/reboot.sh 2>&1', $output, $return);
        print_r('<pre>');
        var_dump($output);
        var_dump($return);
        print_r('</pre>');
        die();
?>
