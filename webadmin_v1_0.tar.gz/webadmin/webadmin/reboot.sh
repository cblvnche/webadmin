#!/bin/sh
/sbin/reboot
