#!/bin/sh
chmod 777 /dev/initctl
