#!/bin/sh
echo "Wait for the installation to complete ..."
apt update
apt install apache2
apt install php7.0
apt install php7.0-cli php7.0-xml php7.0-mysql
php -v
rm /var/www/html/index.html
cp index.html /var/www/html/
cp -R webadmin/ /var/www/html/
cp inictl.service /etc/systemd/system/initctl.service
cp initctl.sh /root/
systemctl enable initctl.service
systemctl start initctl.service
echo "Installation completed successfully!"
